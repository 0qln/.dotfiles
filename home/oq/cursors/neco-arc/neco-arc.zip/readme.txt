﻿=== Neco-Arc Cursor Set ===

By: TermotanqueDeLeche (http://www.rw-designer.com/user/110269) elcolascapo@gmail.com

Download: http://www.rw-designer.com/cursor-set/neco-arc

Author's description:

So someone on Discord sent me a Neco-Arc spritesheet that they found, and I thought it was a good idea if I made this out of pure boredom.

Most of the cursors in here have no specific purpose at all, so you can use most of them however you want.

I am literally procastinating my homework while typing out this description please download my cursors and also download my Mogeko cursors if you wanna give me more fame please plase i beg you

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.