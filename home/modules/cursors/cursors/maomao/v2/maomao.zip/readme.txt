﻿=== Maomao Cursor Set ===

By: PandoraBonf

Download: http://www.rw-designer.com/cursor-set/maomao

Author's description:

Made from a request! I spent quite a bit of time drawing and animating Maomao, so I really hope she came out recognizable. If you're a fan of The Apothecary Diaries, I hope you'll enjoy using this set as much as I enjoyed making it!

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.